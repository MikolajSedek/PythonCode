Code and data for Data Science presentation - Data Science in Business, Warsaw, 2016-12-07

To run conde you need:

- Linux or Windows Machine (Linux is preffered)
- Anaconda Python 2.4 
- additional modules: xgboost, keras, theano / tensorflow, seaborn, imblearn, h5py

- just download this code and data into some directory, open terminal or anaconda command line, enter the directory in which the code is located, write "jupyter notebook" and hit ENT

- if you have problems running this code write me an email : msedek at gmail.com
